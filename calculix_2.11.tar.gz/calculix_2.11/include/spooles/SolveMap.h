#ifndef _SolveMap_
#define _SolveMap_
#include "SolveMap/SolveMap.h"
#endif
