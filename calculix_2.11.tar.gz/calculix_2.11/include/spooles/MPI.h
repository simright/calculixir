#ifndef _MPI_
#define _MPI_
#include "MPI/spoolesMPI.h"
#endif
