#ifndef _Pencil_
#define _Pencil_
#include "Pencil/Pencil.h"
#endif
