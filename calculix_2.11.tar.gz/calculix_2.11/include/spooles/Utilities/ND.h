/*  ND0.h  */

void   ND0 ( int n1, int n2, int n3, int new_to_old[], 
            int west, int east, int south, int north,
            int bottom, int top ) ;
void   fp2DGrid ( int n1, int n2, int ivec[], FILE *fp ) ;
void   fp3DGrid ( int n1, int n2, int n3, int ivec[], FILE *fp ) ;
