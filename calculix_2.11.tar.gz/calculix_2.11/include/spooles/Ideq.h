#ifndef _Ideq_
#define _Ideq_
#include "Ideq/Ideq.h"
#endif
